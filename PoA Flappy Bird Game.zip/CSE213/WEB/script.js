const bird = document.getElementById("bird");
const obstacleTop = document.getElementById("obstacle-top");
const obstacleBottom = document.getElementById("obstacle-bottom");
const scoreElement = document.getElementById("score");

let birdY = 250; // Bird's vertical position
let gravity = 2; // Gravity force
let isGameOver = false;
let flapStrength = 40; // Bird's jump height
let score = 0;

// Obstacle properties
let obstacleX = 400;
let gap = 150;

// Bird sprites
const birdSprites = {
  midflap: "./bird-assets/yellowbird-midflap.png",
  upflap: "./bird-assets/yellowbird-upflap.png",
  downflap: "./bird-assets/yellowbird-downflap.png",
};

// Function to create clouds
const cloudsContainer = document.getElementById("clouds");
function createCloud() {
  const cloud = document.createElement("div");
  cloud.classList.add("cloud");

  // Randomize cloud position
  cloud.style.top = `${Math.random() * 100}px`;
  cloud.style.left = `${400 + Math.random() * 200}px`;

  // Random animation speed
  const animationDuration = Math.random() * 20 + 15; // Between 15s to 35s duration
  cloud.style.animation = `move-clouds ${animationDuration}s linear infinite`;

  // Add cloud to the container
  cloudsContainer.appendChild(cloud);
}

// Create multiple clouds
for (let i = 0; i < 5; i++) {
  createCloud();
}

// Function to update bird sprite
function setBirdSprite(state) {
  bird.style.backgroundImage = `url('${birdSprites[state]}')`;
}

// Game loop
function updateGame() {
  if (isGameOver) return;

  // Apply gravity
  birdY += gravity;

  // Move obstacles
  obstacleX -= 5;

  if (obstacleX < -50) {
    obstacleX = 400;
    const randomHeight = Math.random() * 200 + 100;
    obstacleTop.style.height = `${randomHeight}px`;
    obstacleBottom.style.height = `${400 - randomHeight - gap}px`;

    // Increment score
    score++;
    scoreElement.textContent = score;
  }

  // Update bird sprite based on movement
  if (birdY < 200) {
    setBirdSprite("upflap");
  } else if (birdY > 300) {
    setBirdSprite("downflap");
  } else {
    setBirdSprite("midflap");
  }

  // Check collision
  checkCollision();

  // Render updates
  renderGame();
}

// Render game elements
function renderGame() {
  bird.style.top = `${birdY}px`;
  obstacleTop.style.left = `${obstacleX}px`;
  obstacleBottom.style.left = `${obstacleX}px`;
}

// Handle collision detection
/*function checkCollision() {
  const birdRect = bird.getBoundingClientRect();
  const obstacleTopRect = obstacleTop.getBoundingClientRect();
  const obstacleBottomRect = obstacleBottom.getBoundingClientRect();
  const groundRect = document.getElementById("ground").getBoundingClientRect();

  if (
    birdRect.top <= obstacleTopRect.bottom ||
    birdRect.bottom >= obstacleBottomRect.top ||
    birdRect.bottom >= groundRect.top
  ) {
    isGameOver = true;
    alert(`Game Over! Your Score: ${score}`);
    location.reload(); // Restart the game
  }
}*/
function checkCollision() {
  const birdRect = bird.getBoundingClientRect();
  const obstacleTopRect = obstacleTop.getBoundingClientRect();
  const obstacleBottomRect = obstacleBottom.getBoundingClientRect();
  const groundRect = document.getElementById("ground").getBoundingClientRect();

  // Check collision with top obstacle
  const hitsTopObstacle =
    birdRect.right > obstacleTopRect.left && // Bird's right side passes obstacle's left edge
    birdRect.left < obstacleTopRect.right && // Bird's left side is before obstacle's right edge
    birdRect.top < obstacleTopRect.bottom; // Bird's top overlaps with obstacle's bottom

  // Check collision with bottom obstacle
  const hitsBottomObstacle =
    birdRect.right > obstacleBottomRect.left && // Bird's right side passes obstacle's left edge
    birdRect.left < obstacleBottomRect.right && // Bird's left side is before obstacle's right edge
    birdRect.bottom > obstacleBottomRect.top; // Bird's bottom overlaps with obstacle's top

  // Check collision with ground
  const hitsGround = birdRect.bottom >= groundRect.top;

  // Game over condition
  if (hitsTopObstacle || hitsBottomObstacle || hitsGround) {
    isGameOver = true;
    alert(`Game Over! Your Score: ${score}`);
    location.reload(); // Restart the game
  }
}



// Flap the bird
document.addEventListener("keydown", (event) => {
  if (event.code === "Space" && !isGameOver) {
    birdY -= flapStrength;
  }
});

// Start the game loop
setInterval(updateGame, 50);
